export * from '@vercel/commerce/types/product'

export type { Product as CommercejsProduct } from '@chec/commerce.js/types/product'
export type { Variant as CommercejsVariant } from '@chec/commerce.js/types/variant'
